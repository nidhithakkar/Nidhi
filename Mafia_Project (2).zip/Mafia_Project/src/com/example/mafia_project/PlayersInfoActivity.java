package com.example.mafia_project;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class PlayersInfoActivity extends Activity {
	Button next, hide, showresults, capture;
	EditText playername, characteristic;
	int alarmNumInt, playerselection;
	TextView showidentity, characters;
	String[] array;
	String randomStr;
	ArrayList<String> wordlist;
	ArrayList<Player> playerList;
	
	
	private static String FILENAME="Mafia";
	
	String allPlayerNamesString = new String();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_players_info);
		View allcharacters= findViewById(R.id.landscapeview);
		
		playerList = new ArrayList<Player>();
		
		Bundle getSel = getIntent().getExtras();
		String selected = getSel.getString("int_value");
		alarmNumInt = Integer.valueOf(selected);
		playerselection=Integer.valueOf(selected);
		if(playerselection==4) {
			
			array=getResources().getStringArray(R.array.FourPlayers);
			wordlist = new ArrayList<String>();
			
		    for (String i : array) 
		        wordlist.add(i);
		    Collections.shuffle(wordlist);
		}
if(playerselection==5) {
			
			array=getResources().getStringArray(R.array.FivePlayers);
			wordlist = new ArrayList<String>();
		    for (String i : array) 
		        wordlist.add(i);
		    Collections.shuffle(wordlist);
		}
if(playerselection==6) {
	
	array=getResources().getStringArray(R.array.SixPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==7) {
	
	array=getResources().getStringArray(R.array.SevenPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==8) {
	
	array=getResources().getStringArray(R.array.EightPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==9) {
	
	array=getResources().getStringArray(R.array.NinePlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==10) {
	
	array=getResources().getStringArray(R.array.TenPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==11) {
	
	array=getResources().getStringArray(R.array.ElevenPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==12) {
	
	array=getResources().getStringArray(R.array.TwelvePlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==13) {
	
	array=getResources().getStringArray(R.array.ThirteenPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==14) {
	
	array=getResources().getStringArray(R.array.FourteenPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}

if(playerselection==15) {
	
	array=getResources().getStringArray(R.array.FifteenPlayers);
	wordlist = new ArrayList<String>();
    for (String i : array) 
        wordlist.add(i);
    Collections.shuffle(wordlist);
}
		showidentity=(TextView)findViewById(R.id.showidentity);
		capture=(Button)findViewById(R.id.screenshot);
		capture.setVisibility(View.INVISIBLE);
		playername=(EditText)findViewById(R.id.writenameofplayers);
		next=(Button)findViewById(R.id.next);
		hide=(Button)findViewById(R.id.hide);
		characters=(TextView)findViewById(R.id.allnames);
		hide.setVisibility(View.INVISIBLE);
		showresults=(Button)findViewById(R.id.showresults);
		showresults.setVisibility(View.INVISIBLE);
		next.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
					if(v.equals(next))	{		
					hide.setVisibility(v.VISIBLE);	
					next.setVisibility(v.INVISIBLE);
					playername.setVisibility(v.INVISIBLE);
					}
					
				/*SharedPreferences settings=getSharedPreferences("MYPREF", 0);
				playername.setText(settings.getString("tvalue", ""));*/
				    if (!wordlist.isEmpty()) {
				        randomStr = wordlist.remove(0);
				        showidentity.setText(randomStr);
				    }
				    
				    playerList.add(new Player(playername.getText().toString(),showidentity.getText().toString()));
				    
				    playername.setText("");
				}
			
		});
		
		hide.setOnClickListener(new OnClickListener() {
			
		
			@Override
			public void onClick(View v) {
				
				next.setVisibility(v.VISIBLE);
				playername.setVisibility(v.VISIBLE);
				if(alarmNumInt-->1){
				hide.setVisibility(v.INVISIBLE);
				}
				else{
					showresults.setVisibility(v.VISIBLE);
					hide.setVisibility(v.INVISIBLE);
					next.setVisibility(v.INVISIBLE);
					//capture.setVisibility(v.VISIBLE);
				}
				showidentity.setText("");
			}
		});
		
		showresults.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {	
				
				addString();
			}
		});
		
		capture.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
			}
		});
	}
	 public void addString()
	  {
		// String allPlayerNamesString = new String();
		 
	    for(Player player: playerList )
	    {
	       allPlayerNamesString=allPlayerNamesString+ player.Name+"-"+player.Type+"\n";
	    }
	    try {
			SaveResults(allPlayerNamesString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}   
	    
	    characters.setText(allPlayerNamesString);
	  }
	 
	 private void SaveResults(String string) throws IOException{
		 
		 FileOutputStream fos = openFileOutput(FILENAME, Context.MODE_PRIVATE);
		 fos.write(string.getBytes());
		 fos.close();
	 }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.players_info, menu);
		return true;
	}

	
	
}


