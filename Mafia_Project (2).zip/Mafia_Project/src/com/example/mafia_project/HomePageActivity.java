package com.example.mafia_project;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class HomePageActivity extends Activity {

	Button start, introduction,showpreviousgameresult;
	TextView showpreviousresults;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home_page);
		start=(Button)findViewById(R.id.start);
		introduction=(Button)findViewById(R.id.introduction);
		showpreviousresults=(TextView)findViewById(R.id.showpreviousresults);
		showpreviousgameresult=(Button)findViewById(R.id.previousresults);
		showpreviousgameresult.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				showpreviousresults.setText(getResults());
			}
		});
		
		//Clicking on start button goes to next activity
		start.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent i = new Intent(HomePageActivity.this, NumberPlayersActivity.class);
				startActivity(i);
			}
		});
		
		introduction.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				showPopUp2();
			}
		});
	}

	private String getResults(){
		String Results="";
		
		FileInputStream fis;
		try {
			fis = openFileInput("Mafia");
		
		int count=fis.available();
		char[] resultArray=new char[count];
		for(int i=0;i<count;i++){
			resultArray[i]=(char)fis.read();
				
		}
		Results = String.copyValueOf(resultArray);
		
		fis.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return Results;
		
	}
	private void showPopUp2() {

		AlertDialog.Builder helpBuilder = new AlertDialog.Builder(this);
		 helpBuilder.setTitle("Rules of the game");
		 helpBuilder.setMessage(" In Mafia and the closely related game Werewolves a group of people sits around a room and tries to figure out which of them are killing off the others. " +
		 		"The upstanding townspeople must figure out who are the Mafia members, or be killed in the night. " +
		 		"At the start of the game, the moderator passes his phone around to each player and each of you will know their roles in the game by this app. " +
		 		"After each player knows their role, give it back to the moderator who will be able to see the roles each player received. " +
		 		"Continue the game which has TWO alternating phases: NIGHT- where the Mafias kill the innocent people, DAY- villagers who are trying to debate and find out who the mafias are. Game continues until all the Mafias are dead(Villagers win) or Mafias equals villagers(Mafias win)");
		 
		 helpBuilder.show();
		 
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home_page, menu);
		return true;
	}

}
