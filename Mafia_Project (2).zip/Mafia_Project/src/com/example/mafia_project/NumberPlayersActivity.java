package com.example.mafia_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.Spinner;

public class NumberPlayersActivity extends Activity {

	Button Start;
	Spinner SelectPlayers;
	String spinner;
	String selected;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_number_players);
		SelectPlayers=(Spinner)findViewById(R.id.PlayersDropdown);
		SelectPlayers.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				spinner=SelectPlayers.getItemAtPosition(arg2).toString();
				selected=SelectPlayers.getItemAtPosition(arg2).toString();
				if(!spinner.matches("Select value")){
					
				
				Start.setVisibility(arg1.VISIBLE);}
				else
				{
					Start.setVisibility(arg1.INVISIBLE);
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
		});
		Start=(Button)findViewById(R.id.Start);
		Start.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				launchnext();			
			}
		});
	}

	private void launchnext() {
		Intent intent=new Intent(NumberPlayersActivity.this, PlayersInfoActivity.class);	
		intent.putExtra("int_value", SelectPlayers.getSelectedItem().toString());
		startActivity(intent);
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.number_players, menu);
		return true;
	}

}
