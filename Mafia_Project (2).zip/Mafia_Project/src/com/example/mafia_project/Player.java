package com.example.mafia_project;

public class Player {

	public String Name;
	
	public String Type;
	
	public Player(String name, String type)
	{
		Name=name;
		Type=type;
	}
}
