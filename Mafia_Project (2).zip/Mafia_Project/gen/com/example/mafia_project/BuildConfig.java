/** Automatically generated file. DO NOT MODIFY */
package com.example.mafia_project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}