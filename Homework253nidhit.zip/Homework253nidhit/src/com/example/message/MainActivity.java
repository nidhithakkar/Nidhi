package com.example.message;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	public static final String TAG = MainActivity.class.getSimpleName();
	StringBuilder mStringBuilder;
	TextView mTextView;
	MediaPlayer beepsound;
	Button stopbutton;
	NotificationManager myNotificationManager;
	Notification myNotification;
	CustomThread myCustom;
	
	//rendering the icon on the notification bar only when the application is running in background
	
	@Override
	public void onPause() {
	    super.onPause();  
		//get notifiction manager
				myNotificationManager=(NotificationManager)this.getSystemService(NOTIFICATION_SERVICE);
				
				//create a pending intent
				Intent pendingintent=new Intent(this, MainActivity.class);
				PendingIntent mPendingIntent=PendingIntent.getActivity(this, 0, pendingintent, 0);
				
				//Create Normal Notification
				myNotification= new Notification.Builder(this)
				.setContentIntent(mPendingIntent)
						.setContentTitle("Notification")
						.setContentText("Application is beeping, select to open")
						.setSmallIcon(R.drawable.notification).build();
				
				//use notification manager to notify
				myNotificationManager.notify(0, myNotification);
				
				
	}
	
	//creating a handler to pass the thread in main UI
	private Handler mHandler=new Handler(){
		@Override
		public void handleMessage(Message msg) {
			addSound((MediaPlayer)msg.obj);
			super.handleMessage(msg);
		}
	};
	
	private class CustomThread extends Thread {
		private Handler mThreadHandler=new Handler();
		private boolean mIsrunning=true;
		public void CustomThread() {
			this.setName("Custom Thread");
		}
		
		 public void setIsRunning(boolean value) {
	           mIsrunning = value;
	        } 
		 
		 @Override
		public void run() {
			 while (mIsrunning) {
	                try {
	                    Thread.sleep(5000);

	                    MediaPlayer output = beepsound;
	                    
	                 // Get a message from the global pool - this is a bit more efficient
	                    Message msg = Message.obtain();
	                    msg.obj = output;
	                    mHandler.sendMessage(msg);

	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	            // super.run();
	        }
			//super.run();
		};
	
		private CustomThread mCustomThread;
		
		
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		mStringBuilder=new StringBuilder();
		mTextView=(TextView) findViewById(R.id.mainTextView);
		//adding beep sound
		beepsound=MediaPlayer.create(this, R.raw.beep);
		addSound(beepsound);
		stopbutton=(Button)findViewById(R.id.stop);
		
		//determine the background and foreground activity
		
		
		
		
		
		//on clicking stop button, the sound stops
		stopbutton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				beepsound.stop();
				mCustomThread.setIsRunning(false);
			}
		});
		
		
        // Start a new CustomThread
        mCustomThread = new CustomThread();
        mCustomThread.setName("CustomThread");
        mCustomThread.start();
        beepsound.start();

	}
	
		private void addSound(MediaPlayer sound) {
			beepsound.start();
	    }
	
	@Override
	protected void onStop() {
		
		
		super.onStop();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}

}
